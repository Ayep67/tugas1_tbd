import os, time, json
from datetime import datetime, timezone
import boto3
from botocore.client import Config
import pandas as pd
from generate_dataset import generate

ACCESS = os.getenv("MINIO_ACCESS_KEY", "minioadmin")
SECRET = os.getenv("MINIO_SECRET_KEY", "minioadmin123")
ENDPOINTS = os.getenv("MINIO_ENDPOINTS", "http://minio1:9000,http://minio2:9000,http://minio3:9000").split(",")
MIN_MIB = int(os.getenv("DATASET_MIN_MIB", "105"))
ROOT = "/app/output"
RAW = f"{ROOT}/transactions_raw.csv"
SILVER = f"{ROOT}/transactions_silver.csv"
GOLD_DIR = f"{ROOT}/gold"
os.makedirs(GOLD_DIR, exist_ok=True)

def client(endpoint):
    return boto3.client("s3", endpoint_url=endpoint, aws_access_key_id=ACCESS,
        aws_secret_access_key=SECRET, config=Config(signature_version="s3v4"),
        region_name="us-east-1")

def wait_for_nodes():
    clients=[]
    for ep in ENDPOINTS:
        c=client(ep)
        for attempt in range(60):
            try:
                c.list_buckets()
                break
            except Exception:
                if attempt == 59: raise
                time.sleep(3)
        clients.append(c)
    return clients

def ensure_buckets(clients):
    for c in clients:
        existing=[b["Name"] for b in c.list_buckets()["Buckets"]]
        for name in ["bronze","silver","gold"]:
            if name not in existing:
                c.create_bucket(Bucket=name)

def upload_all(clients, bucket, key, path, content_type="text/csv"):
    for i,c in enumerate(clients,1):
        c.upload_file(path, bucket, key, ExtraArgs={"ContentType":content_type})
        print(f"Node {i}: s3://{bucket}/{key} berhasil diunggah")

def transform():
    # Schema-on-Write: skema, tipe, nilai wajib, dan aturan bisnis diterapkan saat menulis Silver.
    expected=["transaction_id","transaction_date","customer_id","product","category","quantity",
              "unit_price","discount","region","sales_channel","payment_method","salesperson_id","notes"]
    first=True
    for chunk in pd.read_csv(RAW, chunksize=100000):
        missing=set(expected)-set(chunk.columns)
        if missing: raise ValueError(f"Kolom wajib hilang: {missing}")
        chunk=chunk[expected].copy()
        chunk["transaction_date"]=pd.to_datetime(chunk["transaction_date"], errors="coerce")
        for col in ["quantity","unit_price","discount"]:
            chunk[col]=pd.to_numeric(chunk[col], errors="coerce")
        chunk=chunk.dropna(subset=["transaction_id","transaction_date","product","quantity","unit_price"])
        chunk=chunk[(chunk["quantity"]>0)&(chunk["unit_price"]>0)&(chunk["discount"].between(0,1))]
        for col in ["transaction_id","customer_id","product","category","region","sales_channel","payment_method","salesperson_id"]:
            chunk[col]=chunk[col].astype("string").str.strip()
        chunk["gross_sales"]=chunk["quantity"]*chunk["unit_price"]
        chunk["net_sales"]=chunk["gross_sales"]*(1-chunk["discount"])
        chunk["transaction_date"]=chunk["transaction_date"].dt.strftime("%Y-%m-%d")
        chunk.to_csv(SILVER, mode="w" if first else "a", header=first, index=False)
        first=False
    if first: raise ValueError("Tidak ada data valid untuk ditulis ke Silver")

def create_gold():
    df=pd.read_csv(SILVER, parse_dates=["transaction_date"])
    df["month"]=df["transaction_date"].dt.to_period("M").astype(str)
    df.groupby("month", as_index=False).agg(
        total_transactions=("transaction_id","count"),
        total_revenue=("net_sales","sum"),
        total_units=("quantity","sum")
    ).to_csv(f"{GOLD_DIR}/monthly_performance.csv", index=False)
    df.groupby("region", as_index=False).agg(
        total_transactions=("transaction_id","count"), total_revenue=("net_sales","sum")
    ).sort_values("total_revenue",ascending=False).to_csv(f"{GOLD_DIR}/regional_performance.csv",index=False)
    df.groupby("product", as_index=False).agg(
        total_units=("quantity","sum"), total_revenue=("net_sales","sum")
    ).sort_values("total_revenue",ascending=False).to_csv(f"{GOLD_DIR}/top_products.csv",index=False)
    summary={
      "generated_at_utc":datetime.now(timezone.utc).isoformat(),
      "total_transactions":int(len(df)),
      "total_revenue":round(float(df["net_sales"].sum()),2),
      "total_units_sold":int(df["quantity"].sum()),
      "average_transaction_value":round(float(df["net_sales"].sum()/max(len(df),1)),2),
      "top_region":str(df.groupby("region")["net_sales"].sum().idxmax()),
      "top_product":str(df.groupby("product")["net_sales"].sum().idxmax())
    }
    with open(f"{GOLD_DIR}/executive_summary.json","w",encoding="utf-8") as f:
        json.dump(summary,f,indent=2,ensure_ascii=False)
    print("Ringkasan Gold:", json.dumps(summary,ensure_ascii=False))

def main():
    print("Menunggu tiga node MinIO...")
    clients=wait_for_nodes()
    ensure_buckets(clients)
    generate(RAW, MIN_MIB)
    upload_all(clients,"bronze","transactions/transactions_raw.csv",RAW)
    print("Menerapkan Schema-on-Write Bronze -> Silver...")
    transform()
    upload_all(clients,"silver","transactions/transactions_silver.csv",SILVER)
    create_gold()
    for name in os.listdir(GOLD_DIR):
        upload_all(clients,"gold",f"management/{name}",f"{GOLD_DIR}/{name}",
                   "application/json" if name.endswith(".json") else "text/csv")
    print("SELESAI: Bronze, Silver, Gold tersedia pada ketiga node MinIO.")

if __name__=="__main__":
    main()
