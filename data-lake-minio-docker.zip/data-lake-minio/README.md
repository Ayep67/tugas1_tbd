# Data Lake 3 Node dengan Docker dan MinIO

Proyek ini memenuhi empat instruksi teknis pada Tugas 1 Teknologi Big Data:
1. Menjalankan tiga instance MinIO (simulasi tiga node).
2. Membuat dataset transaksi CSV minimal 105 MiB dan menyimpannya ke Bronze.
3. Menerapkan Schema-on-Write saat transformasi Bronze ke Silver.
4. Membuat data Gold untuk Top Level Management.

## Prasyarat
- Docker Desktop aktif (gunakan Linux containers).
- RAM disarankan minimal 8 GB dan ruang disk kosong minimal 3 GB.
- Koneksi internet untuk mengunduh image pertama kali.

## Menjalankan di Windows PowerShell
Buka PowerShell di folder proyek, lalu jalankan:

```powershell
docker compose up -d minio1 minio2 minio3
docker compose run --rm pipeline
```

Perintah kedua membangun image pipeline jika belum ada, membuat dataset, memprosesnya, lalu mengunggah hasil ke ketiga node. Jika ingin menjalankan otomatis sebagai service:

```powershell
docker compose up --build
```

## Akses MinIO Console
- Node 1: http://localhost:9001
- Node 2: http://localhost:9011
- Node 3: http://localhost:9021

Login:
- Username: `minioadmin`
- Password: `minioadmin123`

Pada setiap node harus terlihat tiga bucket: `bronze`, `silver`, `gold`.

## Memeriksa hasil
File lokal juga tersimpan pada folder `output`:
- `transactions_raw.csv` (Bronze; minimal 105 MiB)
- `transactions_silver.csv` (Silver; data tervalidasi + gross_sales + net_sales)
- `gold/monthly_performance.csv`
- `gold/regional_performance.csv`
- `gold/top_products.csv`
- `gold/executive_summary.json`

Di MinIO:
- Bucket `bronze`: `transactions/transactions_raw.csv`
- Bucket `silver`: `transactions/transactions_silver.csv`
- Bucket `gold`: `management/` berisi laporan manajemen.

## Verifikasi tiga node
Buka masing-masing console (9001, 9011, 9021). Pastikan bucket dan objek yang sama terlihat pada ketiganya. Atau cek log:

```powershell
docker compose logs pipeline
```

Log akan menampilkan pesan unggah berhasil ke Node 1, Node 2, dan Node 3.

## Penjelasan Schema-on-Write
Saat data ditulis ke Silver, program:
- Memastikan semua kolom wajib tersedia.
- Mengubah tanggal menjadi tipe tanggal dan angka menjadi numerik.
- Menghapus baris yang tidak valid.
- Memastikan quantity dan unit_price positif serta discount berada pada rentang 0–1.
- Menghitung gross_sales dan net_sales.
Data baru ditulis sebagai Silver setelah aturan skema diterapkan.

## Catatan penting tentang istilah "3 node fisik"
Compose ini menjalankan tiga container MinIO pada satu Docker host. Ini cocok untuk simulasi dan demonstrasi replikasi tiga node, tetapi **belum merupakan tiga komputer fisik berbeda**. Untuk memenuhi arti literal soal, jalankan satu MinIO pada masing-masing dari tiga komputer/VM dengan volume dan alamat IP masing-masing, lalu sesuaikan endpoint pada pipeline. Ketiga container pada satu laptop tidak boleh dilaporkan sebagai tiga perangkat fisik.

Rancangan ini memakai tiga server MinIO standalone dengan salinan objek ke setiap node (bukan satu cluster distributed-erasure MinIO). Ini dipilih agar demonstrasi tiga node dapat dijalankan pada satu komputer tanpa mengklaim topologi yang tidak benar.

## Menghentikan dan menghapus container
```powershell
docker compose down
```
Untuk menghapus seluruh data volume (PERHATIAN: data MinIO ikut terhapus):
```powershell
docker compose down -v
```

Jika Docker Hub gagal diakses, periksa koneksi internet, login Docker Hub bila diminta (`docker login`), lalu coba `docker pull minio/minio:latest`.
