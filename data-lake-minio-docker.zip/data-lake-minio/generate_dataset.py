import csv, os, random
from datetime import datetime, timedelta

def generate(path, min_mib=105):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    target = min_mib * 1024 * 1024
    products = ["Laptop", "Monitor", "Keyboard", "Mouse", "Printer", "Headset", "SSD", "Router"]
    regions = ["Palembang", "Jakarta", "Bandung", "Surabaya", "Medan", "Yogyakarta"]
    channels = ["Online", "Retail", "Distributor"]
    start = datetime(2024, 1, 1)
    header = ["transaction_id","transaction_date","customer_id","product","category","quantity",
              "unit_price","discount","region","sales_channel","payment_method","salesperson_id","notes"]
    count = 0
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        while os.path.getsize(path) < target:
            for _ in range(50000):
                product = random.choice(products)
                price = random.randint(150000, 18000000)
                qty = random.randint(1, 8)
                dt = start + timedelta(days=random.randint(0, 1000))
                w.writerow([
                    f"TRX-{count+1:09d}", dt.strftime("%Y-%m-%d"),
                    f"CUST-{random.randint(1,250000):06d}", product,
                    "Electronics", qty, price, random.choice([0,0,0,0.05,0.1,0.15]),
                    random.choice(regions), random.choice(channels),
                    random.choice(["Transfer","Credit Card","E-Wallet","Cash"]),
                    f"SP-{random.randint(1,500):04d}",
                    "Generated sample transaction record for big data practicum"
                ])
                count += 1
            f.flush()
    size = os.path.getsize(path)
    print(f"Dataset dibuat: {count:,} baris, {size/1024/1024:.2f} MiB")
    return count
