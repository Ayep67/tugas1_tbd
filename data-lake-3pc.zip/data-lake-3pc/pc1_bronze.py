import os, boto3
from botocore.client import Config
from generate_dataset import generate

ENDPOINT=os.getenv("MINIO_ENDPOINT","http://localhost:9000")
KEY=os.getenv("MINIO_ACCESS_KEY","minioadmin")
SECRET=os.getenv("MINIO_SECRET_KEY","GantiPassword123!")
s3=boto3.client("s3",endpoint_url=ENDPOINT,aws_access_key_id=KEY,
    aws_secret_access_key=SECRET,config=Config(signature_version="s3v4"),region_name="us-east-1")
bucket="bronze"; path="transactions_raw.csv"
try: s3.create_bucket(Bucket=bucket)
except s3.exceptions.BucketAlreadyOwnedByYou: pass
except Exception as e:
    if "BucketAlreadyOwnedByYou" not in str(e) and "BucketAlreadyExists" not in str(e): raise
generate(path,105)
s3.upload_file(path,bucket,"transactions/transactions_raw.csv")
print("BERHASIL: dataset mentah tersimpan di bucket bronze PC 1")
print("Ukuran MiB:",round(os.path.getsize(path)/1024/1024,2))
