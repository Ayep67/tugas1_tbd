# Data Lake 3 PC: MinIO Bronze -> Silver -> Gold

PENTING: project ini menjalankan SATU MinIO standalone pada setiap PC. Ketiga PC bukan satu cluster MinIO; data berpindah antarzona melalui S3 API.

## A. Tentukan IP
Jalankan `ipconfig` di setiap PC dan catat IPv4. Contoh:
- PC1 = 192.168.1.101 (Bronze)
- PC2 = 192.168.1.102 (Silver)
- PC3 = 192.168.1.103 (Gold)

Semua PC harus berada pada LAN yang sama. Buat DHCP reservation/static IP jika memungkinkan. Izinkan inbound TCP 9000 dan 9001 di Windows Firewall untuk jaringan Private. Jangan membuka port ke internet publik.

## B. Siapkan MinIO pada KETIGA PC
Salin `docker-compose.yaml` ke masing-masing PC. Ganti password contoh `GantiPassword123!` dengan password yang sama pada ketiganya. Pastikan Docker Desktop berjalan (Linux containers), lalu di folder tersebut jalankan:
```powershell
docker compose up -d
docker compose ps
```
Dashboard: PC1 `http://IP-PC1:9001`, PC2 `http://IP-PC2:9001`, PC3 `http://IP-PC3:9001`.
API MinIO selalu `http://IP-PC:9000`.
Login `minioadmin` dan password yang dipilih.

## C. Uji koneksi jaringan
Dari PC2:
```powershell
Test-NetConnection 192.168.1.101 -Port 9000
```
Dari PC3:
```powershell
Test-NetConnection 192.168.1.102 -Port 9000
```
Ganti IP sesuai jaringan. Harus `TcpTestSucceeded : True`. Jika False, cek IP, Wi-Fi/LAN, firewall, dan port mapping.

## D. Instal Python dependencies
Di masing-masing PC, install Python 3.10+ lalu di folder project:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```
Jika PowerShell memblokir aktivasi, gunakan `py -m pip install -r requirements.txt` dan jalankan script dengan `py nama_script.py`.

## E. PC 1: Bronze
Salin `pc1_bronze.py`, `generate_dataset.py`, dan `requirements.txt` ke PC1. Jalankan:
```powershell
$env:MINIO_ENDPOINT="http://localhost:9000"
$env:MINIO_ACCESS_KEY="minioadmin"
$env:MINIO_SECRET_KEY="PASSWORD_YANG_DIPILIH"
py pc1_bronze.py
```
Membuat CSV minimal 105 MiB dan upload ke bucket `bronze`, object `transactions/transactions_raw.csv`.

## F. PC 2: Silver
Salin `pc2_silver.py` dan `requirements.txt` ke PC2. Ubah IP PC1 dan password di environment:
```powershell
$env:BRONZE_ENDPOINT="http://192.168.1.101:9000"
$env:SILVER_ENDPOINT="http://localhost:9000"
$env:MINIO_ACCESS_KEY="minioadmin"
$env:MINIO_SECRET_KEY="PASSWORD_YANG_DIPILIH"
py pc2_silver.py
```
Script mengunduh Bronze dari PC1, menerapkan schema-on-write (kolom wajib, tipe tanggal/numerik, buang baris invalid, quantity/unit_price positif, discount 0-1, hitung gross_sales/net_sales), lalu upload hasil ke bucket `silver` PC2.

## G. PC 3: Gold
Salin `pc3_gold.py` dan `requirements.txt` ke PC3. Ubah IP PC2 dan password:
```powershell
$env:SILVER_ENDPOINT="http://192.168.1.102:9000"
$env:GOLD_ENDPOINT="http://localhost:9000"
$env:MINIO_ACCESS_KEY="minioadmin"
$env:MINIO_SECRET_KEY="PASSWORD_YANG_DIPILIH"
py pc3_gold.py
```
Script mengambil Silver dari PC2, membuat laporan bulanan, regional, produk terlaris dan ringkasan eksekutif, lalu upload ke bucket `gold` PC3.

## H. Bukti tugas
- PC1 console: bucket bronze dan ukuran objek >= 100 MiB.
- PC2 console: bucket silver dan objek transactions_silver.csv.
- PC3 console: bucket gold dengan 4 laporan di prefix management/.
- Screenshot `docker compose ps` pada tiap PC.
- Screenshot `Test-NetConnection` sukses.
- Screenshot log/terminal setiap script berhasil.

## Troubleshooting
- `AccessDenied` / `SignatureDoesNotMatch`: pastikan access key dan password sama dengan yang diatur di MinIO pada PC tujuan.
- `Connection timed out`: cek IP, firewall inbound TCP 9000, dan kedua PC satu jaringan.
- `NoSuchBucket`: pastikan bucket sumber telah dibuat dan proses sebelumnya selesai.
- Jangan jalankan script PC2 sebelum upload PC1 selesai; jangan jalankan PC3 sebelum upload PC2 selesai.
- Perubahan environment `$env:...` hanya berlaku di jendela PowerShell yang sedang digunakan.
