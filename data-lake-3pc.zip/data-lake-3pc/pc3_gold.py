import os, json, boto3, pandas as pd
from datetime import datetime, timezone
from botocore.client import Config

SILVER_ENDPOINT=os.getenv("SILVER_ENDPOINT","http://192.168.1.102:9000")
GOLD_ENDPOINT=os.getenv("GOLD_ENDPOINT","http://localhost:9000")
KEY=os.getenv("MINIO_ACCESS_KEY","minioadmin")
SECRET=os.getenv("MINIO_SECRET_KEY","GantiPassword123!")
def client(endpoint):
    return boto3.client("s3",endpoint_url=endpoint,aws_access_key_id=KEY,
        aws_secret_access_key=SECRET,config=Config(signature_version="s3v4"),region_name="us-east-1")
src=client(SILVER_ENDPOINT); dst=client(GOLD_ENDPOINT)
src.download_file("silver","transactions/transactions_silver.csv","transactions_silver.csv")
df=pd.read_csv("transactions_silver.csv",parse_dates=["transaction_date"])
df["month"]=df.transaction_date.dt.to_period("M").astype(str)
os.makedirs("reports",exist_ok=True)
df.groupby("month",as_index=False).agg(total_transactions=("transaction_id","count"),
 total_revenue=("net_sales","sum"),total_units=("quantity","sum")).to_csv("reports/monthly_performance.csv",index=False)
df.groupby("region",as_index=False).agg(total_transactions=("transaction_id","count"),
 total_revenue=("net_sales","sum")).sort_values("total_revenue",ascending=False).to_csv("reports/regional_performance.csv",index=False)
df.groupby("product",as_index=False).agg(total_units=("quantity","sum"),
 total_revenue=("net_sales","sum")).sort_values("total_revenue",ascending=False).to_csv("reports/top_products.csv",index=False)
summary={"generated_at_utc":datetime.now(timezone.utc).isoformat(),
 "total_transactions":int(len(df)),"total_revenue":round(float(df.net_sales.sum()),2),
 "total_units_sold":int(df.quantity.sum()),
 "average_transaction_value":round(float(df.net_sales.sum()/max(len(df),1)),2),
 "top_region":str(df.groupby("region").net_sales.sum().idxmax()),
 "top_product":str(df.groupby("product").net_sales.sum().idxmax())}
with open("reports/executive_summary.json","w",encoding="utf-8") as f: json.dump(summary,f,indent=2,ensure_ascii=False)
try: dst.create_bucket(Bucket="gold")
except Exception: pass
for name in os.listdir("reports"):
    dst.upload_file(f"reports/{name}","gold",f"management/{name}")
print("BERHASIL: laporan Gold tersimpan di PC 3")
print(json.dumps(summary,indent=2,ensure_ascii=False))
