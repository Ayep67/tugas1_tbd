import os, boto3, pandas as pd
from botocore.client import Config

BRONZE_ENDPOINT=os.getenv("BRONZE_ENDPOINT","http://192.168.1.101:9000")
SILVER_ENDPOINT=os.getenv("SILVER_ENDPOINT","http://localhost:9000")
KEY=os.getenv("MINIO_ACCESS_KEY","minioadmin")
SECRET=os.getenv("MINIO_SECRET_KEY","GantiPassword123!")
def client(endpoint):
    return boto3.client("s3",endpoint_url=endpoint,aws_access_key_id=KEY,
        aws_secret_access_key=SECRET,config=Config(signature_version="s3v4"),region_name="us-east-1")
src=client(BRONZE_ENDPOINT); dst=client(SILVER_ENDPOINT)
raw="transactions_raw.csv"; silver="transactions_silver.csv"
src.download_file("bronze","transactions/transactions_raw.csv",raw)
expected=["transaction_id","transaction_date","customer_id","product","category","quantity",
"unit_price","discount","region","sales_channel","payment_method","salesperson_id","notes"]
first=True
for df in pd.read_csv(raw,chunksize=100000):
    missing=set(expected)-set(df.columns)
    if missing: raise ValueError(f"Kolom wajib tidak ada: {missing}")
    df=df[expected].copy()
    df["transaction_date"]=pd.to_datetime(df["transaction_date"],errors="coerce")
    for c in ["quantity","unit_price","discount"]: df[c]=pd.to_numeric(df[c],errors="coerce")
    df=df.dropna(subset=["transaction_id","transaction_date","product","quantity","unit_price"])
    df=df[(df.quantity>0)&(df.unit_price>0)&(df.discount.between(0,1))]
    for c in ["transaction_id","customer_id","product","category","region","sales_channel","payment_method","salesperson_id"]:
        df[c]=df[c].astype("string").str.strip()
    df["gross_sales"]=df.quantity*df.unit_price
    df["net_sales"]=df.gross_sales*(1-df.discount)
    df["transaction_date"]=df["transaction_date"].dt.strftime("%Y-%m-%d")
    df.to_csv(silver,mode="w" if first else "a",header=first,index=False)
    first=False
if first: raise ValueError("Tidak ada baris valid")
try: dst.create_bucket(Bucket="silver")
except Exception: pass
dst.upload_file(silver,"silver","transactions/transactions_silver.csv")
print("BERHASIL: Schema-on-Write selesai, data Silver tersimpan di PC 2")
